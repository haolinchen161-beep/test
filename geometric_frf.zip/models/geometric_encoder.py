"""
geometric_encoder.py — 几何编码器模块。

将几何数据编码为逐点隐特征 (B, N, D)。

提供:
    - GeometricEncoder: 抽象基类
    - SimplePointEncoder: 最简逐点MLP (baseline)
    - PointNetEncoder:   PointNet风格 (MLP + 全局池化 + 拼接)
    - GNNEncoder:        图神经网络编码器 (预留)
"""

import torch
import torch.nn as nn
from .geometry_data import GeometryData


# ============================================================
# 抽象基类
# ============================================================
class GeometricEncoder(nn.Module):
    """几何编码器抽象基类。输入 GeometryData，输出逐点隐特征 (B, N, out_dim)。"""

    def __init__(self, in_channels: int, hidden_dim: int, out_dim: int):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_dim = hidden_dim
        self.out_dim = out_dim

    def forward(self, geometry_data: GeometryData) -> torch.Tensor:
        raise NotImplementedError("子类必须实现 forward 方法")


# ============================================================
# 实现1: SimplePointEncoder — 最简逐点MLP (baseline)
# ============================================================
class SimplePointEncoder(GeometricEncoder):
    """
    最简几何编码器：逐点MLP映射，无全局特征聚合。
    适用场景: 快速baseline测试，点之间关联较弱的任务。
    """

    def __init__(self, in_channels: int = 0, hidden_dim: int = 256, out_dim: int = 256,
                 coord_dim: int = 3, n_layers: int = 4):
        super().__init__(in_channels, hidden_dim, out_dim)
        input_dim = coord_dim + in_channels

        layers = []
        current_dim = input_dim
        for i in range(n_layers):
            if i == n_layers - 1:
                layers.append(nn.Linear(current_dim, out_dim))
            else:
                layers.append(nn.Linear(current_dim, hidden_dim))
                layers.append(nn.ReLU())
                current_dim = hidden_dim
        self.mlp = nn.Sequential(*layers)

    def forward(self, geometry_data: GeometryData) -> torch.Tensor:
        points = geometry_data.points  # (B, N, 3)
        if geometry_data.point_features is not None:
            x = torch.cat([points, geometry_data.point_features], dim=-1)
        else:
            x = points
        return self.mlp(x)  # (B, N, out_dim)


# ============================================================
# 实现2: PointNetEncoder — MLP + 全局池化 + 拼接
# ============================================================
class PointNetEncoder(GeometricEncoder):
    """
    PointNet 风格几何编码器。
    逐点MLP提取局部特征 → 全局最大池化 → 与局部特征拼接 → 融合MLP。
    使每个点的表示同时包含局部几何和全局上下文信息。

    参考: Qi et al., "PointNet: Deep Learning on Point Sets for 3D Classification and Segmentation"
    """

    def __init__(self, in_channels: int = 0, hidden_dim: int = 256, out_dim: int = 256,
                 coord_dim: int = 3, n_layers: int = 3, global_feat_dim: int = 256):
        super().__init__(in_channels, hidden_dim, out_dim)
        input_dim = coord_dim + in_channels

        # 逐点局部特征提取
        local_layers = []
        current_dim = input_dim
        for i in range(n_layers):
            local_layers.append(nn.Linear(current_dim, hidden_dim))
            local_layers.append(nn.ReLU())
            current_dim = hidden_dim
        self.local_mlp = nn.Sequential(*local_layers)

        # 全局特征提取 (max pooling + MLP)
        self.global_mlp = nn.Sequential(
            nn.Linear(hidden_dim, global_feat_dim),
            nn.ReLU(),
            nn.Linear(global_feat_dim, global_feat_dim),
        )

        # 局部+全局融合
        self.fusion_mlp = nn.Sequential(
            nn.Linear(hidden_dim + global_feat_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, geometry_data: GeometryData) -> torch.Tensor:
        points = geometry_data.points  # (B, N, 3)
        if geometry_data.point_features is not None:
            x = torch.cat([points, geometry_data.point_features], dim=-1)
        else:
            x = points

        # 1. 逐点局部特征 (B, N, hidden_dim)
        local_features = self.local_mlp(x)

        # 2. 全局特征: 沿点维度最大池化 (B, global_feat_dim)
        global_features = local_features.max(dim=1)[0]
        global_features = self.global_mlp(global_features)

        # 3. 拼接+融合 (B, N, out_dim)
        global_expanded = global_features.unsqueeze(1).expand(-1, local_features.size(1), -1)
        fused = torch.cat([local_features, global_expanded], dim=-1)
        return self.fusion_mlp(fused)


# ============================================================
# 实现3: GNNEncoder — 图神经网络编码器 (预留)
# ============================================================
class GNNEncoder(GeometricEncoder):
    """
    图神经网络编码器 —— 预留。

    需要网格拓扑 (edge_index) 才能发挥图卷积的消息传递能力。
    当前为占位实现 (等价于 SimplePointEncoder)。

    TODO: 当网格拓扑数据确定后，替换为真正的 GNN 层
          (如 PyG 的 GCNConv / GATConv 或自定义消息传递)。
    """

    def __init__(self, in_channels: int = 0, hidden_dim: int = 256, out_dim: int = 256,
                 coord_dim: int = 3, n_layers: int = 3):
        super().__init__(in_channels, hidden_dim, out_dim)
        self.coord_dim = coord_dim
        self.n_layers = n_layers
        input_dim = coord_dim + in_channels

        layers = []
        current_dim = input_dim
        for i in range(n_layers):
            if i == n_layers - 1:
                layers.append(nn.Linear(current_dim, out_dim))
            else:
                layers.append(nn.Linear(current_dim, hidden_dim))
                layers.append(nn.ReLU())
                current_dim = hidden_dim
        self.mlp = nn.Sequential(*layers)

    def forward(self, geometry_data: GeometryData) -> torch.Tensor:
        """当前占位实现。TODO: 利用 geometry_data.edge_index 做消息传递。"""
        points = geometry_data.points
        if geometry_data.point_features is not None:
            x = torch.cat([points, geometry_data.point_features], dim=-1)
        else:
            x = points
        return self.mlp(x)
